package tbop523420009;

import java.util.Scanner;

public class tbop523420009 {

static Scanner input = new Scanner(System.in);

  public static void main(String[] args) {
  
  String a;

System.out.println(" Stemmer Kata Indonesia Sederhana ");
 System.out.println("---------------------");
 System.out.println("Klik Enter Untuk Stemming");
 System.out.print(" Masukkan Kata : ");
 a = input.nextLine();
System.out.println("----Hasil Stemming----");
System.out.println(a);
   
  }
}
