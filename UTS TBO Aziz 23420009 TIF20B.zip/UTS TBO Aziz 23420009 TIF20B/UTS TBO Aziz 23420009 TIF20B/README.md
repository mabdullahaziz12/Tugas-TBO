# 23419035_tokenization
Simple Tokenization in HTML and JavaScript.

# UTS Teori Bahasa Formal dan Otomata

Nama      : Moch. Nafi'ul Irsad Al A.</br>
NIM       : 23419035</br>
Prodi     : Teknik Informatika</br>
Angkatan  : 2019 Pagi</br>
